--
-- Database : db_deped2k18
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `tbl_backup`
--
DROP TABLE  IF EXISTS `tbl_backup`;
CREATE TABLE `tbl_backup` (
  `backup_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_backup`  VALUES ( "1","backup_13-03-2019.sql.zip","2019-03-13 08:29:19");
INSERT INTO `tbl_backup`  VALUES ( "2","backup_20-03-2019.sql.zip","2019-03-20 02:08:45");


--
-- Tabel structure for table `tbl_booklogs`
--
DROP TABLE  IF EXISTS `tbl_booklogs`;
CREATE TABLE `tbl_booklogs` (
  `booklogs_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `book_id` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `borrower_id` varchar(100) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`booklogs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_booklogs`  VALUES ( "1","5","2019-03-20 00:00:00","1","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "2","3","2019-03-20 00:00:00","1","RC-001","818109236507076569018","Borrowed");


--
-- Tabel structure for table `tbl_books`
--
DROP TABLE  IF EXISTS `tbl_books`;
CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `pages` int(11) NOT NULL,
  `fund` varchar(100) NOT NULL,
  `copyright` varchar(100) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `classification` varchar(100) NOT NULL,
  `qty_in` int(11) NOT NULL,
  `qty_out` int(11) DEFAULT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_books`  VALUES ( "1","fghjk","rudy cana","35","Self","Copyright","gfhj","publisher","000-099","5","3");


--
-- Tabel structure for table `tbl_borrowed`
--
DROP TABLE  IF EXISTS `tbl_borrowed`;
CREATE TABLE `tbl_borrowed` (
  `borrowed_id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `date_borrowed` date NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `borrower_id` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `received_userid` varchar(200) DEFAULT NULL,
  `date_returned` date DEFAULT NULL,
  `booklogs_id` int(11) DEFAULT NULL,
  `booklogs_id2` int(11) DEFAULT NULL,
  PRIMARY KEY (`borrowed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_borrowed`  VALUES ( "1","Okay","Borrowed","Study","2019-03-20","1 c.1","818109236507076569018","RC-001","","","2","");
INSERT INTO `tbl_borrowed`  VALUES ( "2","Okay","Borrowed","Study","2019-03-20","1 c.2","818109236507076569018","RC-001","","","2","");
INSERT INTO `tbl_borrowed`  VALUES ( "3","Okay","Borrowed","Study","2019-03-20","1 c.3","818109236507076569018","RC-001","","","2","");


--
-- Tabel structure for table `tbl_borrowers`
--
DROP TABLE  IF EXISTS `tbl_borrowers`;
CREATE TABLE `tbl_borrowers` (
  `borrower_id` varchar(200) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `contactno` varchar(100) NOT NULL,
  `schoolname` varchar(100) NOT NULL,
  `grade_level` varchar(100) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `date_created` date NOT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`borrower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_borrowers`  VALUES ( "818109236507076569018","Danica","Gdsg","Female","Grade 1","07976986796","Nonescost","","Active","2019-03-20","Yes");


--
-- Tabel structure for table `tbl_copy`
--
DROP TABLE  IF EXISTS `tbl_copy`;
CREATE TABLE `tbl_copy` (
  `copy_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_no` varchar(100) NOT NULL,
  `copy` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `booklogs` int(11) NOT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`copy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_copy`  VALUES ( "1","1 c.1","1","1","1","Borrowed","Okay");
INSERT INTO `tbl_copy`  VALUES ( "2","1 c.2","2","1","1","Borrowed","Okay");
INSERT INTO `tbl_copy`  VALUES ( "3","1 c.3","3","1","1","Borrowed","Okay");
INSERT INTO `tbl_copy`  VALUES ( "4","1 c.4","4","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "5","1 c.5","5","1","1","Received","Okay");


--
-- Tabel structure for table `tbl_employee`
--
DROP TABLE  IF EXISTS `tbl_employee`;
CREATE TABLE `tbl_employee` (
  `user_id` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` varchar(100) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_employee`  VALUES ( "RC-001","Male.jpg","Admin","Admin","Male","Administrator","Escalante City","09123456789","2019-01-22");


--
-- Tabel structure for table `tbl_events`
--
DROP TABLE  IF EXISTS `tbl_events`;
CREATE TABLE `tbl_events` (
  `event_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbl_settings`
--
DROP TABLE  IF EXISTS `tbl_settings`;
CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `school_name` varchar(1000) NOT NULL,
  `system_name` varchar(100) NOT NULL,
  `bg_image` varchar(100) NOT NULL,
  `left_logo` varchar(100) NOT NULL,
  `right_logo` varchar(100) NOT NULL,
  `line1` varchar(100) NOT NULL,
  `line2` varchar(100) NOT NULL,
  `line3` varchar(100) NOT NULL,
  `line4` varchar(100) NOT NULL,
  `line5` varchar(100) NOT NULL,
  `tel_no` varchar(100) NOT NULL,
  `telefax_no` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `web` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbl_settings`  VALUES ( "1","localhost","logo.png","DepED Division Escalante City","E-Library System","bg.jpg","left_logo.png","right_logo.png","Republic of the Philippines","Department of Education","Region VI - Western Visayas","DEPARTMENT OF EDUCATION","Escalante City, Negros Occidental","+63-34-454-0746","+63-34-454-076","deped_escalante001@deped.gov.ph","www.deped.tk");


--
-- Tabel structure for table `tbl_temp`
--
DROP TABLE  IF EXISTS `tbl_temp`;
CREATE TABLE `tbl_temp` (
  `temp_id` int(11) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `user_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbl_user`
--
DROP TABLE  IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `user_id` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user`  VALUES ( "RC-001","admin","admin@gmail.com","21232f297a57a5a743894a0e4a801fc3","1","Active","ju5mo2ne3za4vu3ho4ne1da6gu3zo6je5");


--
-- Tabel structure for table `tbl_userlogs`
--
DROP TABLE  IF EXISTS `tbl_userlogs`;
CREATE TABLE `tbl_userlogs` (
  `log_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `user_id` varchar(200) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_userlogs`  VALUES ( "1","Login","2019-03-13","08:29:17","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "2","Login","2019-03-20","02:08:43","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "3","Add book (Title: fghjk, quantity: 5)","2019-03-20","02:57:42","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "4","Add borrower (Danica Gdsg)","2019-03-20","02:58:04","RC-001");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
