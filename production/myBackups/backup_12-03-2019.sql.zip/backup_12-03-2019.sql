--
-- Database : db_deped2k18
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `tbl_backup`
--
DROP TABLE  IF EXISTS `tbl_backup`;
CREATE TABLE `tbl_backup` (
  `backup_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_backup`  VALUES ( "1","backup_12-03-2019.sql.zip","2019-03-12 10:48:02");


--
-- Tabel structure for table `tbl_booklogs`
--
DROP TABLE  IF EXISTS `tbl_booklogs`;
CREATE TABLE `tbl_booklogs` (
  `booklogs_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `book_id` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `borrower_id` varchar(100) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`booklogs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_booklogs`  VALUES ( "1","10","2019-03-12 00:00:00","1","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "2","10","2019-03-07 00:00:00","2","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "3","10","2019-03-08 00:00:00","3","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "4","10","2019-03-23 00:00:00","4","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "5","10","2019-03-14 00:00:00","5","RC-001","","Received");
INSERT INTO `tbl_booklogs`  VALUES ( "6","2","2019-03-12 00:00:00","1","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "7","2","2019-03-12 00:00:00","2","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "8","2","2019-03-12 10:50:41","1","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "9","2","2019-03-12 10:50:41","2","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "10","2","2019-03-12 00:00:00","1","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "11","2","2019-03-12 00:00:00","2","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "12","2","2019-03-12 00:00:00","3","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "13","2","2019-03-12 00:00:00","4","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "14","2","2019-03-12 00:00:00","5","RC-001","034525492541012369470","Borrowed");
INSERT INTO `tbl_booklogs`  VALUES ( "15","2","2019-03-12 10:52:15","1","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "16","2","2019-03-12 10:52:15","2","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "17","2","2019-03-12 10:52:15","3","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "18","2","2019-03-12 10:52:15","4","RC-001","034525492541012369470","Returned");
INSERT INTO `tbl_booklogs`  VALUES ( "19","2","2019-03-12 10:52:15","5","RC-001","034525492541012369470","Returned");


--
-- Tabel structure for table `tbl_books`
--
DROP TABLE  IF EXISTS `tbl_books`;
CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `pages` int(11) NOT NULL,
  `fund` varchar(100) NOT NULL,
  `copyright` varchar(100) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `classification` varchar(100) NOT NULL,
  `qty_in` int(11) NOT NULL,
  `qty_out` int(11) DEFAULT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_books`  VALUES ( "1","aaaa","aaaa","2323","aaaa","aaaa","aaaa","aaaa","100-199","10","0");
INSERT INTO `tbl_books`  VALUES ( "2","bbbb","bbbb","3434","bbbb","bbbb","bbbb","bbbb","000-099","10","0");
INSERT INTO `tbl_books`  VALUES ( "3","ccc","ccc","4545","ccc","ccc","ccc","ccc","000-099","10","0");
INSERT INTO `tbl_books`  VALUES ( "4","dddd","dddd","24234","dddd","dddd","dddd","dddd","500-599","10","0");
INSERT INTO `tbl_books`  VALUES ( "5","eeee","eeee","3535","eeee","eeee","eeee","eeee","000-099","10","0");


--
-- Tabel structure for table `tbl_borrowed`
--
DROP TABLE  IF EXISTS `tbl_borrowed`;
CREATE TABLE `tbl_borrowed` (
  `borrowed_id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `date_borrowed` date NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `borrower_id` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `received_userid` varchar(200) DEFAULT NULL,
  `date_returned` date DEFAULT NULL,
  `booklogs_id` int(11) DEFAULT NULL,
  `booklogs_id2` int(11) DEFAULT NULL,
  PRIMARY KEY (`borrowed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_borrowed`  VALUES ( "1","Okay","Returned","Study","2019-03-12","1 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","6","8");
INSERT INTO `tbl_borrowed`  VALUES ( "2","Okay","Returned","Study","2019-03-12","1 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","6","8");
INSERT INTO `tbl_borrowed`  VALUES ( "3","Okay","Returned","Study","2019-03-12","2 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","7","9");
INSERT INTO `tbl_borrowed`  VALUES ( "4","Okay","Returned","Study","2019-03-12","2 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","7","9");
INSERT INTO `tbl_borrowed`  VALUES ( "5","Okay","Returned","Study","2019-03-12","1 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","10","15");
INSERT INTO `tbl_borrowed`  VALUES ( "6","Okay","Returned","Study","2019-03-12","1 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","10","15");
INSERT INTO `tbl_borrowed`  VALUES ( "7","Okay","Returned","Study","2019-03-12","2 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","11","16");
INSERT INTO `tbl_borrowed`  VALUES ( "8","Okay","Returned","Study","2019-03-12","2 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","11","16");
INSERT INTO `tbl_borrowed`  VALUES ( "9","Okay","Returned","Study","2019-03-12","3 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","12","17");
INSERT INTO `tbl_borrowed`  VALUES ( "10","Okay","Returned","Study","2019-03-12","3 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","12","17");
INSERT INTO `tbl_borrowed`  VALUES ( "11","Okay","Returned","Study","2019-03-12","4 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","13","18");
INSERT INTO `tbl_borrowed`  VALUES ( "12","Okay","Returned","Study","2019-03-12","4 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","13","18");
INSERT INTO `tbl_borrowed`  VALUES ( "13","Okay","Returned","Study","2019-03-12","5 c.1","034525492541012369470","RC-001","RC-001","2019-03-12","14","19");
INSERT INTO `tbl_borrowed`  VALUES ( "14","Okay","Returned","Study","2019-03-12","5 c.2","034525492541012369470","RC-001","RC-001","2019-03-12","14","19");


--
-- Tabel structure for table `tbl_borrowers`
--
DROP TABLE  IF EXISTS `tbl_borrowers`;
CREATE TABLE `tbl_borrowers` (
  `borrower_id` varchar(200) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `contactno` varchar(100) NOT NULL,
  `schoolname` varchar(100) NOT NULL,
  `grade_level` varchar(100) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `date_created` date NOT NULL,
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`borrower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_borrowers`  VALUES ( "034525492541012369470","Fghjk","Hgfh","Male","Grade 4","09567546786","Nonescost","","Active","2019-03-12","Yes");


--
-- Tabel structure for table `tbl_copy`
--
DROP TABLE  IF EXISTS `tbl_copy`;
CREATE TABLE `tbl_copy` (
  `copy_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_no` varchar(100) NOT NULL,
  `copy` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `booklogs` int(11) NOT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`copy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_copy`  VALUES ( "1","1 c.1","1","1","1","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "2","1 c.2","2","1","1","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "3","1 c.3","3","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "4","1 c.4","4","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "5","1 c.5","5","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "6","1 c.6","6","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "7","1 c.7","7","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "8","1 c.8","8","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "9","1 c.9","9","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "10","1 c.10","10","1","1","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "11","2 c.1","1","2","2","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "12","2 c.2","2","2","2","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "13","2 c.3","3","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "14","2 c.4","4","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "15","2 c.5","5","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "16","2 c.6","6","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "17","2 c.7","7","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "18","2 c.8","8","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "19","2 c.9","9","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "20","2 c.10","10","2","2","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "21","3 c.1","1","3","3","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "22","3 c.2","2","3","3","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "23","3 c.3","3","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "24","3 c.4","4","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "25","3 c.5","5","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "26","3 c.6","6","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "27","3 c.7","7","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "28","3 c.8","8","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "29","3 c.9","9","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "30","3 c.10","10","3","3","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "31","4 c.1","1","4","4","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "32","4 c.2","2","4","4","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "33","4 c.3","3","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "34","4 c.4","4","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "35","4 c.5","5","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "36","4 c.6","6","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "37","4 c.7","7","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "38","4 c.8","8","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "39","4 c.9","9","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "40","4 c.10","10","4","4","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "41","5 c.1","1","5","5","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "42","5 c.2","2","5","5","Returned","Okay");
INSERT INTO `tbl_copy`  VALUES ( "43","5 c.3","3","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "44","5 c.4","4","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "45","5 c.5","5","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "46","5 c.6","6","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "47","5 c.7","7","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "48","5 c.8","8","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "49","5 c.9","9","5","5","Received","Okay");
INSERT INTO `tbl_copy`  VALUES ( "50","5 c.10","10","5","5","Received","Okay");


--
-- Tabel structure for table `tbl_employee`
--
DROP TABLE  IF EXISTS `tbl_employee`;
CREATE TABLE `tbl_employee` (
  `user_id` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` varchar(100) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_employee`  VALUES ( "RC-001","Male.jpg","Admin","Admin","Male","Administrator","Escalante City","09123456789","2019-01-22");


--
-- Tabel structure for table `tbl_events`
--
DROP TABLE  IF EXISTS `tbl_events`;
CREATE TABLE `tbl_events` (
  `event_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbl_settings`
--
DROP TABLE  IF EXISTS `tbl_settings`;
CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `school_name` varchar(1000) NOT NULL,
  `system_name` varchar(100) NOT NULL,
  `bg_image` varchar(100) NOT NULL,
  `left_logo` varchar(100) NOT NULL,
  `right_logo` varchar(100) NOT NULL,
  `line1` varchar(100) NOT NULL,
  `line2` varchar(100) NOT NULL,
  `line3` varchar(100) NOT NULL,
  `line4` varchar(100) NOT NULL,
  `line5` varchar(100) NOT NULL,
  `tel_no` varchar(100) NOT NULL,
  `telefax_no` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `web` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbl_settings`  VALUES ( "1","localhost","logo.png","DepED Division Escalante City","E-Library System","bg.jpg","left_logo.png","right_logo.png","Republic of the Philippines","Department of Education","Region VI - Western Visayas","DEPARTMENT OF EDUCATION","Escalante City, Negros Occidental","+63-34-454-0746","+63-34-454-076","deped_escalante001@deped.gov.ph","www.deped.tk");


--
-- Tabel structure for table `tbl_temp`
--
DROP TABLE  IF EXISTS `tbl_temp`;
CREATE TABLE `tbl_temp` (
  `temp_id` int(11) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `user_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbl_user`
--
DROP TABLE  IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `user_id` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user`  VALUES ( "RC-001","admin","admin@gmail.com","21232f297a57a5a743894a0e4a801fc3","1","Active","su3mo4ne5ha4vu9po8je5ma6gu3do6je3");


--
-- Tabel structure for table `tbl_userlogs`
--
DROP TABLE  IF EXISTS `tbl_userlogs`;
CREATE TABLE `tbl_userlogs` (
  `log_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `user_id` varchar(200) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_userlogs`  VALUES ( "1","Login","2019-03-12","10:48:01","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "2","Add borrower (Fghjk Hgfh)","2019-03-12","10:48:17","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "3","Add book (Title: aaaa, quantity: 10)","2019-03-12","10:48:31","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "4","Add book (Title: bbbb, quantity: 10)","2019-03-12","10:48:43","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "5","Add book (Title: ccc, quantity: 10)","2019-03-12","10:48:58","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "6","Add book (Title: dddd, quantity: 10)","2019-03-12","10:49:15","RC-001");
INSERT INTO `tbl_userlogs`  VALUES ( "7","Add book (Title: eeee, quantity: 10)","2019-03-12","10:49:28","RC-001");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
